
package in.userInterface;

import java.io.File;
import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Welcome {
	

	
	
	public int AddFileInCurrentFolder(String fileName) throws IOException {
		
		
		File f = new File("/Users/khushabupatil/Desktop/Dev/Eclipse_Workspace_Projects/LockedMe.com_copyoftrial/src/com/"+fileName);
		f.createNewFile();
		return 1;
	}
	public void DeleteFileFromExistingFolder(String fileNameToDelete) throws IOException {
		int flag = 0;
		File f1 = new File("/Users/khushabupatil/Desktop/Dev/Eclipse_Workspace_Projects/LockedMe.com_copyoftrial/src/com/");
		File[] arr = f1.listFiles();
		for (File var_file : arr) {
			if(var_file.isFile() && var_file.getName().matches(fileNameToDelete)) {
				flag = 1;
				var_file.delete();
				System.out.println("File Deleted Successfully");
				break;
			}
		
		}
		if(flag != 1) {
			System.out.println("File Not Found");
		}
	}
	
 private static void DisplayDirectoriesAndSubDirectories(File[] array, String fileNameToSearch) throws IOException {

		for (File f : array) {
			
			 if (f.isDirectory()) {
				 	
	                DisplayDirectoriesAndSubDirectories(f.listFiles(), fileNameToSearch);
			 }
		}
	
 }
 
  

	
	
	public static void main(String[] args) throws Exception {
		System.out.println("\n");
		System.out.println("Welcome to LockMe.com Co-sponcered by Lockers Pvt. Ltd ");
		System.out.println("Application Name : LcokedMe.com\n");
		System.out.println("Project Developer Details : Khushabu Pavan Patil.");
		System.out.println("Email id : khushabu.patil20@yahoo.com,\tClass : MS FSD MAR 2022 Cohort 1");
		
		System.out.println("==============================================");
		
		
		Welcome welcome_obj = new Welcome();
		int choice = 0, ch = 0;
		Scanner sc = new Scanner(System.in);
		Scanner sc1 = new Scanner(System.in);
		
		//SearchFileInMainDirectory searchFileobj = new SearchFileInMainDirectory();
		
		
		do {
			System.out.println("Main menu :");
			System.out.println("1. Sort current files in Ascending Order");
			System.out.println("2. User interaction Options (Add, Delete, Search Files)");
			System.out.println("3. Close the application");
			System.out.println("Please Enter your choice : ");
			
			try {
				
					 choice = sc.nextInt();
				 
				int a = 0;
				System.out.println("==============================================");
				switch(choice) {
								
					case 1 : 	
								
								String folder = "/Users/khushabupatil/Desktop/Dev/Eclipse_Workspace_Projects/LockedMe.com_copyoftrial/src";
								
								  List<Path> pathList = new ArrayList<>();
								  
								  try (Stream<Path> stream = Files.walk(Paths.get(folder))) {
								    pathList = stream.filter(Files::isRegularFile)
								          .collect(Collectors.toList());
								  }
								  Collections.sort(pathList);
								  System.out.println("Files sorted in Ascending order");
								  pathList.forEach(System.out::println);
								
							 	break;
							 	
					case 2 :	System.out.println(" Modules :");
								System.out.println("1. Add File ");	
								System.out.println("2. Delete File ");
								System.out.println("3. Search Files ");
								System.out.println("4. Navigate Back to main menu ");
								System.out.println("Please Enter your choice : ");
								
								
								try {
									ch = sc.nextInt();
								
									System.out.println("==============================================");
									switch(ch) {
								
										case 1 :
												System.out.println("Enter file name to add : ");
												String fileName = sc1.nextLine();
												a = welcome_obj.AddFileInCurrentFolder(fileName);
												if(a == 1) {
													System.out.println("File Added successfully");
												}else {
													System.out.println("File Not added");
												}
												break;
										case 2 :
												System.out.println("Enter file name to delete : ");
												String fileNameToDelete = sc1.nextLine();
												welcome_obj.DeleteFileFromExistingFolder(fileNameToDelete);
												break;						
										case 3 :
												System.out.println("Enter file name to search : ");
												String fileNameToSearch = sc1.nextLine();
												String directory = "/Users/khushabupatil/Desktop/Dev/Eclipse_Workspace_Projects/LockedMe.com_copyoftrial/src";
												  File maindir = new File(directory);
												  if (maindir.exists() && maindir.isDirectory()) {											      
											            File arr[] = maindir.listFiles();
											             DisplayDirectoriesAndSubDirectories(arr,fileNameToSearch);
											        }
												break;
										case 4 :
												break;
										default :
											System.out.println("Please enter valid choice(1,2,3 or 4)");
							
									}
								}catch (Exception e) {
									System.out.println("Please enter valid choice(1,2,3 or 4)"+e);
									
								}
								break;
					case 3 : 	System.exit(0);		
					default :
						System.out.println("Please enter valid choice(1,2 or 3)");
				
				 }
			}catch (Exception e) {
				 System.out.println("Please enter valid choice(1,2 or 3)"+e);
				 
			}

		}while(choice != 0);
		
		sc.close();
		sc1.close();
	}

}
